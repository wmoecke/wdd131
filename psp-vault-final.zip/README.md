# PSP Vault — WDD 131 Final Project

Copy the `project` folder into the root of your `wdd131` repository.

## Pages
- `index.html`: home page
- `games.html`: dynamic catalogue with genre filter and localStorage favorites
- `setup.html`: HTML form, dynamic collection planner, and localStorage persistence
- `references.html`: credits for external images
- `siteplan.html`: Week 05 planning document preserved in the same folder

## Before submission
1. Open the pages through a local development server such as VS Code Live Server.
2. Check the browser console for JavaScript errors.
3. Test mobile and desktop views in DevTools.
4. Run Lighthouse for Performance, Accessibility, Best Practices, and SEO.
5. Push to GitHub and submit:
   `https://wmoecke.github.io/wdd131/project/`
